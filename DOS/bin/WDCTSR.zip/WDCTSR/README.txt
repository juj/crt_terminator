WDCTSR.EXE: a TSR that enables WDC90C33 External RAMDAC bit whenever it is seen to be disabled.
WDCTSR2.EXE: Same as WDCTSR.EXE, but does not mirror the VGA palette to CRT Terminator after the External RAMDAC bit is flipped.
