CRT Terminator firmware updater utility.
Provided firmware are (C) Oulainen Multimedia Group, licensed only for use with CRT Terminator products.

Zadig (C) https://zadig.akeo.ie/
OpenFPGALoader (C) https://github.com/trabucayre/openFPGALoader
Node.js (C) https://nodejs.org/

For usage instructions and firmware ChangeLog, see https://oummg.com/manual/#firmware_update
